# Add utility functions here if needed
